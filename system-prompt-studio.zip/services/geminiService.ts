
import { GoogleGenAI } from "@google/genai";

export const tailorPromptWithGemini = async (basePrompt: string, collegeName: string): Promise<string> => {
  if (!process.env.API_KEY) {
    // In a real app, you'd want more robust handling, but for this context, an error is fine.
    throw new Error("API_KEY environment variable not set. Please configure it to use the AI Tailoring feature.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const instruction = `You are an expert in crafting system prompts for AI chatbots. Your task is to take the following base system prompt for a "College Club Finder Bot" and tailor it specifically for "${collegeName}". 

Your modifications should be subtle and professional. Weave the college name and identity naturally into the prompt to make it feel personalized. For example, you can mention the college name in the bot's introduction or purpose.

Do NOT change the core instructions, tone, personality, response guidelines, or structure. The goal is personalization, not a rewrite. Return ONLY the full, modified system prompt text.

Here is the base prompt to modify:
---
${basePrompt}
---
`;

  try {
    