
export type AddOnKeys = 'eventPromotion' | 'applicationHelper' | 'feedbackCollection';

export interface AddOnsState {
  eventPromotion: boolean;
  applicationHelper: boolean;
  feedbackCollection: boolean;
}
