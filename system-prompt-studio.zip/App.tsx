
import React, { useState, useEffect, useCallback } from 'react';
import { INITIAL_SYSTEM_PROMPT, ADD_ON_PROMPTS } from './constants';
import type { AddOnKeys, AddOnsState } from './types';
import { tailorPromptWithGemini } from './services/geminiService';
import Header from './components/Header';
import PromptEditor from './components/PromptEditor';
import PromptPreview from './components/PromptPreview';
import { SparklesIcon } from './components/IconComponents';

function App() {
  const [mainPrompt, setMainPrompt] = useState<string>(INITIAL_SYSTEM_PROMPT);
  const [addOns, setAddOns] = useState<AddOnsState>({
    eventPromotion: false,
    applicationHelper: false,
    feedbackCollection: false,
  });
  const [collegeName, setCollegeName] = useState<string>('');
  const [generatedPrompt, setGeneratedPrompt] = useState<string>('');
  const [isTailoring, setIsTailoring] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let finalPrompt = mainPrompt;
    let addOnHeaderAdded = false;

    const addHeaderIfNeeded = () => {
      if (!addOnHeaderAdded) {
        finalPrompt += `\n\n---
✨ Optional Add-on Prompts (for specific behaviors)`;
        addOnHeaderAdded = true;
      }
    };

    if (addOns.eventPromotion) {
      addHeaderIfNeeded();
      finalPrompt += ADD_ON_PROMPTS.eventPromotion;
    }
    if (addOns.applicationHelper) {
      addHeaderIfNeeded();
      finalPrompt += ADD_ON_PROMPTS.applicationHelper;
    }
    if (addOns.feedbackCollection) {
      addHeaderIfNeeded();
      finalPrompt += ADD_ON_PROMPTS.feedbackCollection;
    }
    setGeneratedPrompt(finalPrompt);
  }, [mainPrompt, addOns]);

  const handleToggleAddOn = useCallback((key: AddOnKeys) => {
    setAddOns(prev => ({ ...prev, [key]: !prev[key] }));
  }, []);

  const handleTailorPrompt = async () => {
    if (!collegeName.trim()) {
        setError("Please enter a college name to tailor the prompt.");
        return;
    }
    setIsTailoring(true);
    setError(null);
    try {
      const tailoredPrompt = await tailorPromptWithGemini(INITIAL_SYSTEM_PROMPT, collegeName);
      setMainPrompt(tailoredPrompt);
    } catch (e) {
      setError(e instanceof Error ? e.message : "An unknown error occurred.");
    } finally {
      setIsTailoring(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-800">
      <Header />
      <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          <PromptEditor
            mainPrompt={mainPrompt}
            onMainPromptChange={setMainPrompt}
            addOns={addOns}
            onToggleAddOn={handleToggleAddOn}
            collegeName={collegeName}
            onCollegeNameChange={setCollegeName}
            onTailor={handleTailorPrompt}
            isTailoring={isTailoring}
          />
          <PromptPreview generatedPrompt={generatedPrompt} />
        </div>
        {error && (
            <div 
                className="fixed bottom-5 right-5 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg shadow-lg z-50 flex items-center"
                role="alert"
            >
                <strong className="font-bold mr-2">Error:</strong>
                <span className="block sm:inline">{error}</span>
                <button onClick={() => setError(null)} className="ml-4 text-red-700 font-bold">X</button>
            </div>
        )}
      </main>
      <footer className="text-center py-4 text-slate-500 text-sm">
        <p>Built with React, TypeScript, and the Gemini API.</p>
      </footer>
    </div>
  );
}

export default App;
